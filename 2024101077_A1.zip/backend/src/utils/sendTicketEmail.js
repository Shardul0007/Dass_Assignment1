const { sendEmail } = require("./mailer");

async function sendTicketEmail(toEmail, ticketId, qrBase64, details = {}) {
  if (!toEmail) throw new Error("Recipient email missing");

  const eventName = details.eventName ? String(details.eventName) : "";
  const participantName = details.participantName
    ? String(details.participantName)
    : "";
  const participantEmail = details.participantEmail
    ? String(details.participantEmail)
    : "";

  const subject = "Your Event Ticket";

  // SMTP clients work best with CID attachments; HTTPS email providers work best with data-URIs.
  const smtpHtml = `
    <h2>Registration Successful</h2>
    ${eventName ? `<p><b>Event:</b> ${eventName}</p>` : ""}
    ${participantName ? `<p><b>Participant:</b> ${participantName}</p>` : ""}
    ${participantEmail ? `<p><b>Email:</b> ${participantEmail}</p>` : ""}
    <p><b>Ticket ID:</b> ${ticketId}</p>
    <p><b>QR Code:</b></p>
    <img alt="QR" src="cid:qr-code"/>
    <hr/>
    <p>If the QR image is blocked, use this Ticket ID at the venue.</p>
  `;

  const resendHtml = `
    <h2>Registration Successful</h2>
    ${eventName ? `<p><b>Event:</b> ${eventName}</p>` : ""}
    ${participantName ? `<p><b>Participant:</b> ${participantName}</p>` : ""}
    ${participantEmail ? `<p><b>Email:</b> ${participantEmail}</p>` : ""}
    <p><b>Ticket ID:</b> ${ticketId}</p>
    <p><b>QR Code:</b></p>
    <p>Your QR code is attached as <b>ticket-qr.png</b>.</p>
    <hr/>
    <p>If the QR image is blocked, use this Ticket ID at the venue.</p>
  `;

  const attachments = [
    {
      filename: "ticket-qr.png",
      content: qrBase64.split("base64,")[1],
      encoding: "base64",
      cid: "qr-code",
    },
  ];

  const { provider, info } = await sendEmail({
    to: toEmail,
    subject,
    html: smtpHtml,
    attachments,
    resendHtml,
  });

  console.log("Ticket email sent:", {
    to: toEmail,
    ticketId,
    provider,
    messageId: info?.messageId,
    response: info?.response,
  });

  return info;
}

module.exports = sendTicketEmail;
